<?php
const BASE_UPLOAD_DIR = "uploads";
if(!file_exists(BASE_UPLOAD_DIR)){
    mkdir(BASE_UPLOAD_DIR);
}

$json = ["success" => true, "errors" => [],];


if(isset($_FILES["file"]) && !empty($_FILES["file"]["name"])) {
    $file = $_FILES["file"];

// файл в временной папке
    $oldPath = $file["tmp_name"];

    $name = $file["name"];
//$pos = strpos($name, ".");
//$ext = substr($name, $pos + 1);
//var_dump($ext);

    $info = pathinfo($name);
    $baseName = $info["basename"];
    $ext = $info["extension"];
    switch ($ext) {
        case "jpeg":
        case "png":
        case "giff":
        case "svg":
        case "jpg":
        case "webp":
            $newPath = BASE_UPLOAD_DIR . "/" . time() . "_" . $baseName;
            break;
        default:
            $json["errors"]["file"] = "Формат неверный";
            $json["success"] = false;
            $newPath = "";
            break;
    }

    if (!empty($newPath)) {

        move_uploaded_file($oldPath, $newPath);
    }
}
header("Content-Type: application/json");
echo json_encode($json);