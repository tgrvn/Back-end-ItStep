<?php
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        .error{
            color: red;
        }
    </style>
</head>
<body>

<?php


if(isset($_SESSION["error_msg"])){
    echo "<p class='error'>".$_SESSION["error_msg"]."</p>";
    unset($_SESSION["error_msg"]);
}

session_write_close();
?>

<form id="form-file" method="post" enctype="multipart/form-data">
    <label>Upload File Single
        <input id="file" type="file" name="file"  />
    </label>
    <button type="submit" name="upload_file">Save</button>
</form>

<script>
    let form = document.getElementById("form-file");
    let file = form.querySelector("#file");
    form.addEventListener("submit", async function (e){
        e.preventDefault();
        let formData = new FormData();
        formData.append("file", file.files[0]);

        let response = await fetch("send_file_json.php", {
            method: "POST",
            body: formData,
        });

        let json = await  response.json();

        if(!json.success){
            console.log(json);
            document.write(`<p class='error'>${json.errors.file}</p>`)
        }else{
            document.write("<p>Success</p>");
        }

    })
</script>

</body>
</html>