<?php
session_start();
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <style>
        .error{
            color: red;
        }
    </style>
</head>
<body>

<?php


if(isset($_SESSION["error_msg"])){
    echo "<p class='error'>".$_SESSION["error_msg"]."</p>";
    unset($_SESSION["error_msg"]);
}

session_write_close();
?>

<form action="send_file.php" method="post" enctype="multipart/form-data">
    <label>Upload File Single
        <input id="file" type="file" name="file"  />
    </label>
    <br>
    <label>Upload File Multiple
        <input id="file2" type="file" name="multiple_files[]" multiple  />
    </label>
    <button type="submit" name="upload_file">Save</button>
</form>

</body>
</html>