<?php

$mss = [];

$mss[] = [
    "name" => "",
    "src" => ""
];