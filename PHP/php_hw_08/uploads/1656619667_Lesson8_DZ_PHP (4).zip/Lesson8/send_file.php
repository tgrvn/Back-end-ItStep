<?php
const BASE_UPLOAD_DIR = "uploads";
if(!file_exists(BASE_UPLOAD_DIR)){
    mkdir(BASE_UPLOAD_DIR);
}


if(isset($_FILES["file"]) && !empty($_FILES["file"]["name"])) {
    $file = $_FILES["file"];

// файл в временной папке
    $oldPath = $file["tmp_name"];

    $name = $file["name"];
//$pos = strpos($name, ".");
//$ext = substr($name, $pos + 1);
//var_dump($ext);

    $info = pathinfo($name);
    $baseName = $info["basename"];
    $ext = $info["extension"];
    switch ($ext) {
        case "jpeg":
        case "png":
        case "giff":
        case "svg":
        case "jpg":
        case "webp":
            $newPath = BASE_UPLOAD_DIR . "/" . time() . "_" . $baseName;
            break;
        default:
            session_start();
            $_SESSION["error_msg"] = "Формат неверный";
            $newPath = "";
            session_write_close();
            break;
    }

    if (!empty($newPath)) {

        move_uploaded_file($oldPath, $newPath);
    }
}

if(isset($_FILES["multiple_files"]) && !empty($_FILES["multiple_files"]["name"])) {
    $multiple = $_FILES["multiple_files"];

    foreach ($multiple["error"] as $key => $error) {
        if ($error == UPLOAD_ERR_OK) {
            $tmp_name = $multiple["tmp_name"][$key];
            // basename() может спасти от атак на файловую систему;
            // может понадобиться дополнительная проверка/очистка имени файла
            $name = $multiple["name"][$key];
            $newPath = BASE_UPLOAD_DIR . "/" . time() . "_" . $name;
            move_uploaded_file($tmp_name, $newPath);
        }
    }

}
header("Location: upload_file.php");