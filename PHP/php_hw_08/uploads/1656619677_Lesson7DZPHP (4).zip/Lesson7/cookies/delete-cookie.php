<?php

setcookie("name", $_POST["name"] ?? "", time() - (60 * 60));
setcookie("age", $_POST["age"] ?? "", time() - (60 * 60));
setcookie("email", $_POST["email"] ?? "", time() - (60 * 60));

echo "Cookies Delete";
