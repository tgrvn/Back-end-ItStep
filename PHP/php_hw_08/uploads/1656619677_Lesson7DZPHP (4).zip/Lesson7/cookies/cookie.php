<form action="cookie_step2.php" method="post">
    <input type="text" name="name" value="<?= $_COOKIE["name"] ?? "" ?>" placeholder="name">
    <input type="number" name="age" value="<?= $_COOKIE["age"] ?? "" ?>" placeholder="age">
    <input type="email" name="email" value="<?= $_COOKIE["email"] ?? "" ?>" placeholder="email">
    <button type="submit">Next</button>
</form>

<a href="delete-cookie.php">Delete cookie</a>