<?php

if(count($_POST) > 0) {

    setcookie("name", $_POST["name"] ?? "", time() + (60 * 60));
    setcookie("age", $_POST["age"] ?? "", time() + (60 * 60));
    setcookie("email", $_POST["email"] ?? "", time() + (60 * 60));
}
?>

<p>Name: <?= $_COOKIE["name"] ?></p>
<p>Age: <?= $_COOKIE["age"] ?></p>
<p>Email: <?= $_COOKIE["email"] ?></p>

<a href="cookie.php">Back</a>