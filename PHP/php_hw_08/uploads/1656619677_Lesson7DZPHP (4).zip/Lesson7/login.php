<?php

include_once "functions.php";
if(count($_POST) > 0 && login($_POST)){
    header("Location: admin.php");
}
echo ifExistsError();
?>


<form method="post">
    <input type="email" name="email" placeholder="Email">
    <input type="password" name="password" placeholder="Password">
    <button type="submit">Login</button>

</form>
<a href="register.php">Register</a>