<?php
include_once "functions.php";

$errors = [];
if(count($_POST) > 0){
    if(register($_POST, $errors)){
        echo "<p class='success'>Success</p>";
    }
}
?>

<form method="post">
    <input type="text" name="name" value="<?= $_POST["name"] ?? ""?>" placeholder="Name">
    <input type="email" name="email" value="<?= $_POST["email"] ?? ""?>" placeholder="Email">
    <input type="password" name="password" placeholder="Password">
    <?= isset($errors["password"]) ? '<p class="error">'.$errors["password"].'</p>' : ""?>
    <input type="password" name="confirm_password"  placeholder="Confirm Password">
    <button type="submit">Register</button>
</form>