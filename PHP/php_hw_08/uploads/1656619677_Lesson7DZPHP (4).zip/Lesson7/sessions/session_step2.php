<?php

session_start();

if(count($_POST) > 0) {

    $_SESSION["name"] = $_POST["name"] ?? "";
    $_SESSION["age"] = $_POST["age"] ?? "";
    $_SESSION["email"] = $_POST["email"] ?? "";
}
?>

<p>Name: <?= $_SESSION["name"] ?></p>
<p>Age: <?= $_SESSION["age"] ?></p>
<p>Email: <?= $_SESSION["email"] ?></p>

<a href="session.php">Back</a>