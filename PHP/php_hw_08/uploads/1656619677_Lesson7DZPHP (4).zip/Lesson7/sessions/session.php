<?php
session_start();
var_dump($_SESSION);
?>

ID: <?= session_id() ?>



<form action="session_step2.php" method="post">
    <input type="text" name="name" value="<?= $_SESSION["name"] ?? "" ?>" placeholder="name">
    <input type="number" name="age" value="<?= $_SESSION["age"] ?? "" ?>" placeholder="age">
    <input type="email" name="email" value="<?= $_SESSION["email"] ?? "" ?>" placeholder="email">
    <button type="submit">Next</button>
</form>

<a href="delete-session.php">Delete cookie</a>