<?php

const FILE_NAME = "users.json";

function getJSON(){
    $strJSON = "[]";
    if(file_exists(FILE_NAME)){
        $strJSON = file_get_contents(FILE_NAME);
    }

    return json_decode($strJSON, true);
}

function setJSON($fructs){
    $strJSON = json_encode($fructs);
    file_put_contents(FILE_NAME, $strJSON);
}

function isAuth(){
    return isset($_COOKIE["name"]) && !empty($_COOKIE["name"]);
}

function getHash($password){
    return md5("j7h" . md5($password) . "9jm");
}

function register($user, &$errors){
    $name = $user["name"];
    $email = $user["email"];
    $password = $user["password"];
    $confirm_password = $user["confirm_password"];

    if($password != $confirm_password){
        $errors["password"] = "Пароль неверный";
    }

    $users = getJSON();
    if(count($errors) == 0){
        $users[] = [
            "name" => $name,
            "email" => $email,
            "password" => getHash($password),
        ];
    }

    file_put_contents(FILE_NAME, json_encode($users));

    return count($errors) == 0;
}

function login($user){
    $email = $user["email"];
    $password = $user["password"];

    $hash = getHash($password);

    $users = getJSON();
    foreach ($users as $u){
        if($u["email"] == $email && $u["password"] == $hash){
            setcookie("name", $u["name"], time() + 3600);
            return true;
        }
    }

    return false;
}

function setErrorMsg($msg){
    session_start();
    $_SESSION["error_msg"] = $msg;
    session_write_close();
}

function ifExistsError(){
    session_start();
    $msg = "";
    if(isset($_SESSION["error_msg"]) && !empty($_SESSION["error_msg"])){
        $msg = "<p class='error'>".$_SESSION["error_msg"]."</p>";
        unset($_SESSION["error_msg"]);
    }
    session_write_close();
    return $msg;

}